Game Title: GENSOU-CARD1
ROM Size: 8 MB
Save Type: 256K SRAM/FRAM (32 KB)

Flash ID Check:
[   ROM   ] FE FF 0F EA 24 FF AE 51 
[   555/A9] 20 00 10 88 02 00 FF FF 
[  5555/A9] 20 00 10 88 02 00 FF FF 
[   AAA/A9] 20 00 10 88 02 00 FF FF 
[  AAAA/A9] 20 00 10 88 02 00 FF FF 
[  4555/A9] 20 00 10 88 02 00 FF FF 
[  7555/A9] 20 00 10 88 02 00 FF FF 
[  4AAA/A9] 20 00 10 88 02 00 FF FF 
[  7AAA/A9] 20 00 10 88 02 00 FF FF 
[     0/90] 20 00 10 88 02 00 FF FF 

Common Flash Interface Data:
Swapped pins: (0, 1)
Device size: 0x0800000 (8.00 MB)
Voltage: 1.7–2.0 V
Single write: True
Buffered write: False
Sector erase: 1024–4096 ms
Sector flags: 0x80
Region 1: 0x0000000–0x07EFFFF @ 0x10000 Bytes × 127
Region 2: 0x07F0000–0x07FFFFF @ 0x2000 Bytes × 8

Compatible Cartridge Types:
- AA1030_TSOP88BALL with M36W0R603*

FlashGBX v3.18 | GBxCart RW v1.3 – Firmware L1 (COM3)


Instructions:

- Please use the original jp version of the rom and apply the english patch from here:
https://www.romhacking.net/translations/1720/
- Patch the game with the batteryless patch